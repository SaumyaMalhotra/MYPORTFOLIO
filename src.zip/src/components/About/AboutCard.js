import React from "react";
import Card from "react-bootstrap/Card";
import { ImPointRight } from "react-icons/im";

function AboutCard() {
  return (
    <Card className="quote-card-view">
      <Card.Body>
        <blockquote className="blockquote mb-0">
          <p style={{ textAlign: "justify" }}>
            Hi Everyone, I am <span className="purple">Saumya Malhotra </span>
            from <span className="purple"> New Delhi, India.</span>
            <br />
            Dynamic and highly motivated Computer Science and Engineering student at IITM with hands-on experience in Web development, currently working as an intern at Interware.Proven ability to tackle complex problems with innovative solutions.
            <br />
            Apart from coding, some other activities that I love to do!
          </p>
          <ul>
            <li className="about-activity">
              <ImPointRight /> Art
            </li>
            <li className="about-activity">
              <ImPointRight /> Web Surfing
            </li>
            <li className="about-activity">
              <ImPointRight /> Travelling
            </li>
          </ul>

        </blockquote>
      </Card.Body>
    </Card>
  );
}

export default AboutCard;
