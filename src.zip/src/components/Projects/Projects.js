import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import ProjectCard from "./ProjectCards";
import Particle from "../particles";
import spons from "../../Assets/Projects/spons.png";
import zero from "../../Assets/Projects/zero.png";
import safe from "../../Assets/Projects/safe.png";

function Projects() {
  return (
    <Container fluid className="project-section">
       <Particle/>
      <Container>
        <h1 className="project-heading">
          My Recent <strong className="purple">Works </strong>
        </h1>
        <p style={{ color: "white" }}>
          Here are a few projects I've worked on recently.
        </p>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={zero}
              isBlog={false}
              title="Zero Kaata"
              ghLink="https://github.com/SaumyaMalhotra/zerokaataOX.github.io"
              demoLink="http://127.0.0.1:5500/text.html"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={safe}
              isBlog={false}
              title="Safety Precaution Website"
              ghLink="https://github.com/SaumyaMalhotra/help.github.io"
              demoLink="http://127.0.0.1:5500/project/hackathon/Home.html"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={spons}
              isBlog={false}
              title="Sponser Page"
              ghLink="https://github.com/SaumyaMalhotra/sponserpageweek2"
              demoLink="https://matrix.iitminternware.com/Sponsors"
            />
          </Col>

        </Row>
      </Container>
    </Container>
  );
}

export default Projects;
